const $ = (s) => document.querySelector(s);
const loginView = $("#login-view"), dashboardView = $("#dashboard-view");
let currentUser = null, toastTimer;
const escapeHTML = (v="") => String(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const labels = {not_submitted:"Not submitted",pending:"Pending review",approved:"Approved",changes_requested:"Changes requested",rejected:"Not approved"};
const icons = ["✿","◈","✧","⌁","✳"];
function toast(message){const el=$("#toast");el.textContent=message;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),2800)}
async function api(url, options={}) {
  const response = await fetch(url,{...options,headers:options.body instanceof FormData?options.headers:{"Content-Type":"application/json",...(options.headers||{})},credentials:"same-origin"});
  const data = await response.json().catch(()=>({}));
  if(!response.ok) throw new Error(data.error||"Something went wrong.");
  return data;
}
async function checkSession(){
  try{const data=await api("/api/me");if(data.user){currentUser=data.user;showDashboard();await refresh();startPolling()}else showLogin()}catch{showLogin()}
}
function showLogin(){loginView.classList.remove("hidden");dashboardView.classList.add("hidden")}
function showDashboard(){loginView.classList.add("hidden");dashboardView.classList.remove("hidden");$("#role-kicker").textContent=currentUser.role==="admin"?"ADMIN CONTROL CENTRE":"YOUR CREATIVE WORKSPACE";$("#welcome-title").innerHTML=currentUser.role==="admin"?'Review the work<span class="title-dot">.</span>':'Your drawings<span class="title-dot">.</span>';$("#welcome-subtitle").textContent=currentUser.role==="admin"?"Every submission, one clear decision at a time.":"Upload your drawings and track each review.";$("#collection-title").textContent=currentUser.role==="admin"?"All five submissions":"Your five topics"}
$("#login-form").addEventListener("submit",async e=>{e.preventDefault();$("#login-error").textContent="";const button=e.currentTarget.querySelector("button");button.disabled=true;try{const data=await api("/api/login",{method:"POST",body:JSON.stringify({username:$("#username").value,password:$("#password").value})});currentUser=data.user;showDashboard();await refresh();startPolling()}catch(err){$("#login-error").textContent=err.message}finally{button.disabled=false}});
$("#logout").addEventListener("click",async()=>{try{await api("/api/logout",{method:"POST",body:"{}"})}catch{}currentUser=null;stopPolling();showLogin();toast("Signed out securely.")});
async function refresh(){if(!currentUser)return;try{const data=await api("/api/drawings");render(data.drawings,data.payment);await renderPaymentHistory()}catch(e){if(e.message.includes("log in")){stopPolling();showLogin()}else toast(e.message)}}
function render(drawings,payment){
 const approved=drawings.filter(d=>d.status==="approved").length,pending=drawings.filter(d=>d.status==="pending").length;
 $("#count-total").textContent=drawings.length;$("#count-pending").textContent=pending;$("#count-approved").textContent=`${approved}/5`;
 $("#drawings-grid").innerHTML=drawings.map((d,i)=>`<article class="drawing-card" style="animation-delay:${i*45}ms">
  <div class="card-art">${d.image_url?`<img src="${d.image_url}?v=${encodeURIComponent(d.submitted_at||"")}" alt="${escapeHTML(d.topic_name)} drawing preview">`:`<span class="placeholder-art">${icons[i]}</span>`}<span class="topic-number">TOPIC 0${d.topic_number}</span></div>
  <div class="card-body"><div class="card-top"><div><h3>${escapeHTML(d.topic_name)}</h3><div class="filename">${d.has_upload?escapeHTML(d.original_name||"Drawing uploaded"):"No drawing uploaded yet"}</div></div><span class="status-badge ${d.status}">${labels[d.status]}</span></div>
  ${d.feedback?`<div class="feedback"><strong>Admin feedback:</strong> ${escapeHTML(d.feedback)}</div>`:""}
  ${currentUser.role==="student"?studentControls(d):adminControls(d)}
  </div></article>`).join("");
 const allApproved=approved===5;
 $("#payment-status").textContent=payment.status==="paid"?"Paid":"Pending";
 $("#payment-status").className="status-badge "+(payment.status==="paid"?"approved":"pending");
 $("#payment-message").textContent=payment.status==="paid"?"Payment marked complete by admin.":allApproved?"All drawings are approved. Waiting for the payment to be marked complete.":`${approved} of 5 drawings approved. Payment stays pending until every drawing is approved.`;
 let adminTools=$("#admin-payment-tools");if(adminTools)adminTools.remove();
 if(currentUser.role==="admin"){
   const tools=document.createElement("div");tools.id="admin-payment-tools";tools.className="admin-payment";
   tools.innerHTML=`<span class="muted">Admin payment control</span><button id="mark-paid" ${!allApproved||payment.status==="paid"?"disabled":""}>Mark ₹90 as paid</button><button id="mark-pending" ${payment.status!=="paid"?"disabled":""}>Undo paid status</button>`;
   $(".payment-card").appendChild(tools);
   $("#mark-paid").addEventListener("click",()=>updatePayment("paid"));
   $("#mark-pending").addEventListener("click",()=>updatePayment("pending"));
 }
}
function studentControls(d){return `<label class="topic-label">Topic name<input class="topic-name-input" type="text" maxlength="100" value="${escapeHTML(d.topic_name)}" data-topic="${d.id}" ${d.status==="approved"?"disabled":""}></label><div class="upload-row"><label class="upload-label ${d.status==="approved"?"disabled":""}">＋ ${d.has_upload?"Replace image":"Upload drawing"}<input type="file" accept="image/jpeg,image/png,image/webp" data-upload="${d.id}" ${d.status==="approved"?"disabled":""}></label></div><div class="upload-hint">${d.status==="approved"?"Approved drawings are locked.": "JPG, PNG or WebP · max 8 MB"}</div>`}
function adminControls(d){return d.has_upload?`<textarea class="feedback-input" id="feedback-${d.id}" rows="2" maxlength="500" placeholder="Optional feedback for your friend...">${escapeHTML(d.feedback)}</textarea><div class="admin-actions"><button class="approve-btn" data-review="approve" data-id="${d.id}">✓ Approve</button><button class="changes-btn" data-review="changes" data-id="${d.id}">↻ Request changes</button><button class="reject-btn" data-review="reject" data-id="${d.id}">× Reject</button></div>`:`<div class="upload-hint">Waiting for the student to upload this drawing.</div>`}
$("#drawings-grid").addEventListener("change",async e=>{const input=e.target.closest("[data-upload]");if(!input||!input.files[0])return;const file=input.files[0];if(file.size>8*1024*1024){toast("Image must be 8 MB or smaller.");input.value="";return}const form=new FormData();form.append("drawing",file);const topicInput=$(`[data-topic="${input.dataset.upload}"]`);form.append("topic_name",topicInput?topicInput.value:"");try{await api(`/api/drawings/${input.dataset.upload}/upload`,{method:"POST",body:form,headers:{}});toast("Drawing submitted for review ✨");await refresh()}catch(err){toast(err.message)}finally{input.value=""}});
$("#drawings-grid").addEventListener("click",async e=>{const button=e.target.closest("[data-review]");if(!button)return;const id=button.dataset.id,action=button.dataset.review;try{await api(`/api/admin/drawings/${id}`,{method:"PATCH",body:JSON.stringify({action,feedback:$(`#feedback-${id}`).value})});toast(action==="approve"?"Drawing approved ✓":action==="changes"?"Changes requested.":"Drawing marked not approved.");await refresh()}catch(err){toast(err.message)}});

async function renderPaymentHistory(){
 try{
  const data=await api("/api/payment-history");
  const rows=data.history||[];
  $("#history-count").textContent=`${rows.length} ${rows.length===1?"event":"events"}`;
  if(!rows.length){$("#payment-history").innerHTML='<div class="history-empty">No payment changes yet. Your payment timeline will appear here.</div>';return}
  $("#payment-history").innerHTML=rows.map((item,i)=>{
   const date=new Date(item.created_at);
   const dateText=isNaN(date.getTime())?item.created_at:date.toLocaleString([], {dateStyle:"medium",timeStyle:"short"});
   const paid=item.status==="paid";
   return `<article class="history-item" style="animation-delay:${Math.min(i,8)*45}ms">
    <div class="history-icon ${paid?"paid":"waiting"}">${paid?"✓":"◷"}</div>
    <div class="history-details"><div class="history-title">${paid?"Payment marked paid":"Payment pending"}</div><div class="history-meta">${escapeHTML(dateText)} · by ${escapeHTML(item.changed_by)}</div>${item.note?`<div class="history-note">${escapeHTML(item.note)}</div>`:""}<div class="history-method">Gift card · Manual status record</div></div>
    <div class="history-amount">₹${item.amount}<span class="status-badge ${paid?"approved":"pending"}">${paid?"Paid":"Pending"}</span></div>
   </article>`;
  }).join("");
 }catch(e){$("#payment-history").innerHTML='<div class="history-empty">Payment history is temporarily unavailable.</div>'}
}
async function updatePayment(status){try{await api("/api/admin/payment",{method:"PATCH",body:JSON.stringify({status,note:status==="paid"?"Marked paid by admin":"Payment reset to pending"})});toast(status==="paid"?"Payment marked as paid.":"Payment status reset.");await refresh()}catch(err){toast(err.message)}}
let poller=null;function startPolling(){stopPolling();poller=setInterval(refresh,5000)}function stopPolling(){if(poller)clearInterval(poller);poller=null}
checkSession();
