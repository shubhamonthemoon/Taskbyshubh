# DrawingDesk — GitHub + Render deployment

This project is a Node.js app, **not a GitHub Pages static site**. GitHub stores the code; Render runs the backend and serves the website. The same UI and features remain in the app: student/admin login, five drawing uploads, review statuses, and payment activity history.

## Deploy using only an Android phone

1. Extract `drawing-approval-website.zip` on your phone (Files app or an archive app).
2. In a browser, sign in to GitHub and create a **private** repository, e.g. `drawing-approval-website`.
3. Upload the *contents* of the extracted folder to the repository root. Do not upload `node_modules`, `.env`, passwords, private drawings, or the ZIP inside the repo.
4. Open Render in your browser and sign in with GitHub: https://render.com/
5. In Render, create a **Blueprint** from that GitHub repository. Render reads `render.yaml` and asks you to enter the four secrets: `ADMIN_USERNAME`, `ADMIN_PASSWORD`, `STUDENT_USERNAME`, and `STUDENT_PASSWORD`.
6. Use unique passwords at least 8 characters long. Keep the repository private and never put passwords or gift-card codes in source files.
7. Deploy, wait for the build to finish, then open the `https://...onrender.com` URL Render gives you.
8. Test both logins, upload/review a sample drawing, and confirm the payment history updates.

## Important hosting notes

- The Blueprint requests a 1 GB persistent disk so SQLite database, login sessions, and uploaded images survive service restarts/redeploys. Render persistent disks may incur charges; check the current price before confirming deployment.
- If Render asks you to confirm a paid plan/disk, do not confirm until you are comfortable with the cost. Do not remove persistent storage unless you have moved the database and uploads to persistent services; otherwise data may be lost on restart/redeploy.
- GitHub Pages alone cannot run this project's Node.js backend, secure sessions, SQLite database, or file uploads.
- Payment is currently a **manual status record only**. It does not redeem or verify a gift card. Never collect or store gift-card codes in this app.
- This package is prepared for deployment, but it has not been deployed to your accounts. You must create the GitHub repository and Render service yourself.
