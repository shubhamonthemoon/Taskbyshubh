require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const multer = require("multer");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, "data");
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(ROOT, "uploads");
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.error("Set SESSION_SECRET in .env to a random value at least 32 characters long.");
  process.exit(1);
}
for (const key of ["ADMIN_USERNAME", "ADMIN_PASSWORD", "STUDENT_USERNAME", "STUDENT_PASSWORD"]) {
  if (!process.env[key] || process.env[key].length < 8 && key.endsWith("PASSWORD")) {
    console.error(`Set ${key} in .env (passwords must be at least 8 characters).`);
    process.exit(1);
  }
}

const db = new Database(path.join(DATA_DIR, "app.db"));
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('admin','student'))
  );
  CREATE TABLE IF NOT EXISTS drawings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic_number INTEGER UNIQUE NOT NULL CHECK(topic_number BETWEEN 1 AND 5),
    topic_name TEXT NOT NULL,
    filename TEXT,
    original_name TEXT,
    status TEXT NOT NULL DEFAULT 'not_submitted'
      CHECK(status IN ('not_submitted','pending','approved','changes_requested','rejected')),
    feedback TEXT NOT NULL DEFAULT '',
    submitted_at TEXT,
    reviewed_at TEXT
  );
  CREATE TABLE IF NOT EXISTS payment (
    id INTEGER PRIMARY KEY CHECK(id = 1),
    amount INTEGER NOT NULL DEFAULT 90,
    status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','paid')),
    note TEXT NOT NULL DEFAULT '',
    updated_at TEXT
  );
  CREATE TABLE IF NOT EXISTS payment_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    amount INTEGER NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('pending','paid')),
    method TEXT NOT NULL DEFAULT 'gift_card_manual',
    note TEXT NOT NULL DEFAULT '',
    changed_by TEXT NOT NULL,
    created_at TEXT NOT NULL
  );
`);
const now = () => new Date().toISOString();
const seedUser = (username, password, role) => {
  const existing = db.prepare("SELECT id FROM users WHERE username = ?").get(username);
  if (!existing) db.prepare("INSERT INTO users (username,password_hash,role) VALUES (?,?,?)")
    .run(username, bcrypt.hashSync(password, 12), role);
};
seedUser(process.env.ADMIN_USERNAME, process.env.ADMIN_PASSWORD, "admin");
seedUser(process.env.STUDENT_USERNAME, process.env.STUDENT_PASSWORD, "student");

const defaultTopics = [
  "Topic 1 — Nature",
  "Topic 2 — Still Life",
  "Topic 3 — Festival",
  "Topic 4 — Landscape",
  "Topic 5 — Free Choice"
];
for (let i = 1; i <= 5; i++) {
  if (!db.prepare("SELECT id FROM drawings WHERE topic_number = ?").get(i)) {
    db.prepare("INSERT INTO drawings (topic_number,topic_name) VALUES (?,?)").run(i, defaultTopics[i-1]);
  }
}
if (!db.prepare("SELECT id FROM payment WHERE id=1").get()) {
  db.prepare("INSERT INTO payment (id,amount,status) VALUES (1,90,'pending')").run();
}

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "30kb" }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  name: "drawing.sid",
  store: new SQLiteStore({ db: "sessions.sqlite", dir: DATA_DIR }),
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 8 * 60 * 60 * 1000
  }
}));
app.use("/api/login", rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false }));

const requireAuth = (req, res, next) => {
  if (!req.session.user) return res.status(401).json({ error: "Please log in first." });
  next();
};
const requireRole = role => (req, res, next) => {
  if (!req.session.user) return res.status(401).json({ error: "Please log in first." });
  if (req.session.user.role !== role) return res.status(403).json({ error: "You do not have permission." });
  next();
};
const safeDrawing = row => ({
  id: row.id, topic_number: row.topic_number, topic_name: row.topic_name,
  image_url: row.filename ? `/api/drawings/${row.id}/image` : null,
  has_upload: !!row.filename, original_name: row.original_name,
  status: row.status, feedback: row.feedback, submitted_at: row.submitted_at,
  reviewed_at: row.reviewed_at
});
const getDrawings = () => db.prepare("SELECT * FROM drawings ORDER BY topic_number").all();
const getPayment = () => db.prepare("SELECT amount,status,note,updated_at FROM payment WHERE id=1").get();

app.post("/api/login", (req, res, next) => {
  const { username, password } = req.body || {};
  if (typeof username !== "string" || typeof password !== "string") return res.status(400).json({ error: "Enter username and password." });
  const user = db.prepare("SELECT * FROM users WHERE username=?").get(username.trim());
  if (!user || !bcrypt.compareSync(password, user.password_hash)) return res.status(401).json({ error: "Incorrect username or password." });
  req.session.regenerate(err => {
    if (err) return next(err);
    req.session.user = { id: user.id, username: user.username, role: user.role };
    req.session.save(err2 => {
      if (err2) return next(err2);
      res.json({ user: req.session.user });
    });
  });
});
app.post("/api/logout", requireAuth, (req, res, next) => req.session.destroy(err => {
  if (err) return next(err);
  res.clearCookie("drawing.sid", { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production" });
  res.json({ ok: true });
}));
app.get("/api/me", (req, res) => res.json({ user: req.session.user || null }));

app.get("/api/drawings", requireAuth, (req, res) => res.json({ drawings: getDrawings().map(safeDrawing), payment: getPayment() }));
app.get("/api/drawings/:id/image", requireAuth, (req, res) => {
  const row = db.prepare("SELECT filename,original_name FROM drawings WHERE id=?").get(Number(req.params.id));
  if (!row || !row.filename) return res.status(404).end();
  res.setHeader("Cache-Control", "private, no-store");
  res.type(path.extname(row.filename) === ".png" ? "png" : path.extname(row.filename) === ".webp" ? "webp" : "jpeg");
  res.sendFile(path.join(UPLOAD_DIR, row.filename));
});

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, _file, cb) => cb(null, `${Date.now()}-${require("crypto").randomBytes(12).toString("hex")}`)
});
const upload = multer({
  storage,
  limits: { fileSize: 8 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    const allowed = ["image/jpeg", "image/png", "image/webp"];
    if (!allowed.includes(file.mimetype)) return cb(new Error("Only JPG, PNG, and WebP images are allowed."));
    cb(null, true);
  }
});
app.post("/api/drawings/:id/upload", requireRole("student"), upload.single("drawing"), (req, res) => {
  const id = Number(req.params.id);
  const row = db.prepare("SELECT * FROM drawings WHERE id=?").get(id);
  if (!row) { if (req.file) fs.unlinkSync(req.file.path); return res.status(404).json({ error: "Topic not found." }); }
  if (row.status === "approved") { if (req.file) fs.unlinkSync(req.file.path); return res.status(409).json({ error: "This drawing is approved and locked. Ask the admin to reopen it if a change is needed." }); }
  if (!req.file) return res.status(400).json({ error: "Choose an image first." });
  const topicName = typeof req.body.topic_name === "string" ? req.body.topic_name.trim().slice(0, 100) : row.topic_name;
  if (!topicName) { fs.unlinkSync(req.file.path); return res.status(400).json({ error: "Enter a topic name." }); }
  // Check file signature rather than trusting the browser's MIME type.
  const buffer = Buffer.alloc(12);
  const fd = fs.openSync(req.file.path, "r");
  const bytesRead = fs.readSync(fd, buffer, 0, 12, 0);
  fs.closeSync(fd);
  const b = buffer.subarray(0, bytesRead);
  const valid = (b[0]===0xff && b[1]===0xd8 && b[2]===0xff) ||
    (b[0]===0x89 && b.subarray(1,4).toString()==="PNG") ||
    (b.subarray(0,4).toString()==="RIFF" && b.subarray(8,12).toString()==="WEBP");
  if (!valid) { fs.unlinkSync(req.file.path); return res.status(400).json({ error: "That file is not a valid JPG, PNG, or WebP image." }); }
  if (row.filename) {
    const old = path.join(UPLOAD_DIR, row.filename);
    if (fs.existsSync(old)) fs.unlinkSync(old);
  }
  const ext = req.file.mimetype === "image/png" ? ".png" : req.file.mimetype === "image/webp" ? ".webp" : ".jpg";
  const filename = req.file.filename + ext;
  fs.renameSync(req.file.path, path.join(UPLOAD_DIR, filename));
  db.prepare(`UPDATE drawings SET topic_name=?, filename=?, original_name=?, status='pending', feedback='', submitted_at=?, reviewed_at=NULL WHERE id=?`)
    .run(topicName, filename, path.basename(req.file.originalname).slice(0,160), now(), id);
  res.json({ ok: true, drawing: safeDrawing(db.prepare("SELECT * FROM drawings WHERE id=?").get(id)) });
});

app.patch("/api/admin/drawings/:id", requireRole("admin"), (req, res) => {
  const id = Number(req.params.id);
  const { action, feedback } = req.body || {};
  const statusByAction = { approve: "approved", changes: "changes_requested", reject: "rejected" };
  if (!statusByAction[action]) return res.status(400).json({ error: "Choose a valid review action." });
  const row = db.prepare("SELECT * FROM drawings WHERE id=?").get(id);
  if (!row) return res.status(404).json({ error: "Topic not found." });
  if (!row.filename) return res.status(400).json({ error: "Upload a drawing before reviewing it." });
  db.prepare("UPDATE drawings SET status=?,feedback=?,reviewed_at=? WHERE id=?")
    .run(statusByAction[action], typeof feedback === "string" ? feedback.slice(0,500) : "", now(), id);
  res.json({ ok: true, drawing: safeDrawing(db.prepare("SELECT * FROM drawings WHERE id=?").get(id)) });
});
app.patch("/api/admin/payment", requireRole("admin"), (req, res) => {
  const { status, note } = req.body || {};
  if (!["pending","paid"].includes(status)) return res.status(400).json({ error: "Invalid payment status." });
  const allApproved = getDrawings().every(d => d.status === "approved");
  if (status === "paid" && !allApproved) return res.status(400).json({ error: "Approve all five drawings before marking payment as paid." });
  const cleanNote = typeof note === "string" ? note.slice(0,300) : "";
  const previous = getPayment();
  db.prepare("UPDATE payment SET status=?,note=?,updated_at=? WHERE id=1")
    .run(status, cleanNote, now());
  if (previous.status !== status || previous.note !== cleanNote) {
    db.prepare("INSERT INTO payment_history (amount,status,method,note,changed_by,created_at) VALUES (?,?,?,?,?,?)")
      .run(previous.amount, status, "gift_card_manual", cleanNote, req.session.user.username, now());
  }
  res.json({ ok: true, payment: getPayment() });
});
app.get("/api/payment-history", requireAuth, (req, res) => {
  const rows = db.prepare("SELECT id,amount,status,method,note,changed_by,created_at FROM payment_history ORDER BY id DESC LIMIT 100").all();
  res.json({ history: rows });
});

app.use(express.static(path.join(ROOT, "public")));
app.get("*", (_req, res) => res.sendFile(path.join(ROOT, "public", "index.html")));
app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError) return res.status(400).json({ error: err.code === "LIMIT_FILE_SIZE" ? "Image must be 8 MB or smaller." : "Upload could not be processed." });
  if (err) return res.status(400).json({ error: err.message || "Something went wrong." });
  res.status(500).json({ error: "Server error." });
});
app.listen(PORT, () => console.log(`DrawingDesk running at http://localhost:${PORT}`));
